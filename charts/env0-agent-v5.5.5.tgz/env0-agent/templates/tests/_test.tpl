{{- define "env0-agent.test" -}}
apiVersion: v1
kind: Pod
metadata:
  name: &name "{{ include "env0-agent.releaseName" .root }}-{{ .testName }}-test"
  annotations:
    "helm.sh/hook": test
    "helm.sh/hook-delete-policy": hook-succeeded
spec:
  restartPolicy: Never
  {{ if or ( .root.Values.agentImagePullSecret ) ( .root.Values.agentImagePullSecretRef ) }}
  imagePullSecrets:
    - name: {{ if .root.Values.agentImagePullSecret }}env0-image-pull-secret-{{ .root.Release.Name }}{{ else }}{{ .root.Values.agentImagePullSecretRef }}{{ end }}
  {{ end }}
  {{ if .persistentVolumeClaim }}
  volumes:
    - name: env0-state-volume
      persistentVolumeClaim:
        claimName: env0-state-volume-claim
  {{- end }}
  containers:
    - name: *name
      image: {{ .root.Values.dockerImage }}
      imagePullPolicy: Always
      {{ if .persistentVolumeClaim -}}
      volumeMounts:
        - name: env0-state-volume
          mountPath: {{ include "env0-agent.stateMountPath" .root }}
        - name: env0-state-volume
          mountPath: "/mnt/shared"
      {{- end }}
      {{ if .env -}}
      env:
{{ include .env .root | indent 8 }}
      {{- end }}
      command:
        - /bin/bash
        - -ec
        - |
{{ include .commands .root | indent 10 }}

{{ if .tolerationsAndAffinity }}
  {{ if .root.Values.tolerations }}
  # Warning - every whitespace here matters
  tolerations: {{ range $i, $toleration := .root.Values.tolerations }}
    -
    {{ range $k, $v := $toleration }}  {{ $k }}: {{ $v }}
    {{ end }}{{ end }}
  {{ end }}
  {{ if .root.Values.affinity }}
  affinity: {{ .root.Values.affinity | toYaml | trim | nindent 10 }}
  {{ end }}
{{- end -}}
{{- end -}}
